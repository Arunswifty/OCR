//
//  FormViewController.swift
//  OCR_POC
//
//  Created by Arun Krishnan M on 17/02/25.
//

import UIKit

class FormViewController: UIViewController {
    var extractedData: ExtractedData?

    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var stateTextField: UITextField!
    @IBOutlet weak var countryTextField: UITextField!
    @IBOutlet weak var pincodeTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUpUI()
    }
    
    private func setUpUI() {
        let barButton = UIBarButtonItem(image: UIImage(systemName: "doc.on.clipboard"), style: .plain, target: self, action: #selector(barButtonTapped))
        navigationItem.rightBarButtonItem = barButton
    }
    
    @objc func barButtonTapped() {
        processRemainingText()
    }
    
    func processRemainingText() {
        print("Extracted data", extractedData)
        guard let data = extractedData else { return }
        var fieldValues: [String: String] = [:]
        var unprocessedLines: [String] = [] // Store any remaining unprocessed text
        
        print("Extracted data ----->>>>> \(extractedData)");
        let fieldMapping: [String: String] = [
            "city": "city",
            "state": "state",
            "zip": "zip",
            "pincode": "zip",
            "country": "country"
        ]

        let lines = data.unfilledText.components(separatedBy: "\n")

        for line in lines {
            var matched = false
            for (key, field) in fieldMapping {
                if line.lowercased().contains(key) {
                    fieldValues[field] = TextExtractionHelper.extractValue(from: line)
                    matched = true
                    break
                }
            }
            if !matched { // If line doesn’t match any field, store it
                unprocessedLines.append(line)
            }
        }

        // Store extracted values
        extractedData?.city = fieldValues["city"] ?? ""
        extractedData?.state = fieldValues["state"] ?? ""
        extractedData?.zip = fieldValues["zip"] ?? ""
        extractedData?.country = fieldValues["country"] ?? ""
        extractedData?.unfilledText = unprocessedLines.joined(separator: "\n") // Remaining unmatched text

        DispatchQueue.main.async {
            self.cityTextField.text = self.extractedData?.city
            self.stateTextField.text = self.extractedData?.state
            self.pincodeTextField.text = self.extractedData?.zip
            self.countryTextField.text = self.extractedData?.country
        }
    }
}
