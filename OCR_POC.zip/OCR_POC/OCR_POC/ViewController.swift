//
//  ViewController.swift
//  OCR_POC
//
//  Created by Arun Krishnan M on 05/02/25.
//

import UIKit
import Vision

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var scanOcr: UIButton!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var lastNameText: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var descriptionText: UITextField!
    var extractedData = ExtractedData() // Store extracted data
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        title = "Optimal char recognition"
    }
    
    private func setUpUI() {
        let barButton = UIBarButtonItem(image: UIImage(systemName: "chevron.right"), style: .plain, target: self, action: #selector(barButtonTapped))
        navigationItem.rightBarButtonItem = barButton
    }
    
    @objc func barButtonTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let destinationVC = storyboard.instantiateViewController(withIdentifier: "FormViewController") as? FormViewController {
            destinationVC.extractedData = extractedData
            navigationController?.pushViewController(destinationVC, animated: true)
        }
    }
    
    @IBAction func scanAction(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true)
    }
    
    @IBAction func selectImage(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            recognizeText(from: image)
        }
        picker.dismiss(animated: true)
    }
}

extension ViewController {
    func recognizeText(from image: UIImage) {
        guard let cgImage = image.cgImage else { return }
        
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation], error == nil else { return }
            
            let extractedText = observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            DispatchQueue.main.async {
                self.firstNameText.text = extractedText
                self.mapTextToFields(text: extractedText)
            }
        }
        
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        DispatchQueue.global(qos: .userInitiated).async {
            try? handler.perform([request])
        }
    }
    
    func mapTextToFields(text: String) {
        var fieldValues: [String: String] = [:]
        var unprocessedLines: [String] = []
        
        let lines = text.components(separatedBy: "\n")

        
        // Define field mappings
        let fieldMapping: [String: String] = [
            "first name": "firstName",
            "last name": "lastName",
            "email": "email",
            "phone": "phoneNumber",
            "mobile": "phoneNumber",
            "full name": "fullName",
            "address": "address",
            "description": "description"
        ]
        
        for line in lines {
            var matched = false
            for (key, field) in fieldMapping {
                if line.lowercased().contains(key) {
                    fieldValues[field] = TextExtractionHelper.extractValue(from: line)
                    matched = true
                    break
                }
            }
            if !matched {
                unprocessedLines.append(line)
            }
        }
        
        extractedData.firstName = fieldValues["firstName"] ?? ""
        extractedData.lastName = fieldValues["lastName"] ?? ""
        extractedData.email = fieldValues["email"] ?? ""
        extractedData.phoneNumber = fieldValues["phoneNumber"] ?? ""
        extractedData.fullName = fieldValues["fullName"] ?? ""
        extractedData.address = fieldValues["address"] ?? ""
        extractedData.description = fieldValues["description"] ?? ""
        extractedData.unfilledText = unprocessedLines.joined(separator: "\n")
                
        DispatchQueue.main.async {
            self.firstNameText.text = self.extractedData.firstName
            self.lastNameText.text = self.extractedData.lastName
            self.mobileTextField.text = self.extractedData.phoneNumber
            self.addressTextField.text = self.extractedData.address
            self.descriptionText.text = self.extractedData.description
        }
    }
}
