//
//  Common.swift
//  OCR_POC
//
//  Created by Arun Krishnan M on 17/02/25.
//


import Foundation

struct ExtractedData {
    var firstName: String = ""
    var lastName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var fullName: String = ""
    var address: String = ""
    var description: String = ""
    var city: String = ""
    var state: String = ""
    var zip: String = ""
    var zipCode: String = ""
    var pinCode: String = ""
    var country: String = ""
    
    var unfilledText: String = ""
}

struct TextExtractionHelper {
    static func extractValue(from line: String) -> String {
        let pattern = #"(?i)(?:first name|last name|email|phone|mobile|full name|description|address|city|state|zipcode|zip|pincode|country|company|title)\s*[:\-=\s]\s*(.+)"#
        
        do {
            let regex = try NSRegularExpression(pattern: pattern, options: [])
            if let match = regex.firstMatch(in: line, options: [], range: NSRange(location: 0, length: line.utf16.count)) {
                if let valueRange = Range(match.range(at: 1), in: line) {
                    return line[valueRange].trimmingCharacters(in: .whitespacesAndNewlines)
                }
            }
        } catch {
            print("Regex Error:", error)
        }
        
        return ""
    }
}
